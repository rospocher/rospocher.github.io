latex2owl: the format and tool for ontology authoring
-----------------------------------------------------
Version 1.6 July, 2009

Authors:
  Andrei Tamilin and Luciano Serafini
  FBK-IRST, Data & Knowlegde Management Unit
  surname@fbk.eu

Usage: latex2owl [-options]

where options include:
	-in  Input file with an ontology authored in the latex2owl format
	-out Output OWL ontology file

E.g., latex2owl -in examples/test.txt -out examples/test.owl

Documentation:
  doc/latex2owl_manual.pdf gives an overview of the authoring format and gives some practical advices on the authoring process

Examples:
  examples/test.txt contains a simple example of ontological axioms written in the latex-style authoring format
